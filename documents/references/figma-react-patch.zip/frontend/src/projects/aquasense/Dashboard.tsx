import React, { useEffect } from 'react';
import { Dashboard, LiveChart, ThresholdChart } from '../../core/components';
import { FigmaDashboardContent, type StatusMetric } from '../../core/components/FigmaDashboard';
import { aquasenseConfig } from './config';
import { useDataBridge } from '../../core/hooks/useDataBridge';
import { useScenarioStore, useSystemStore, useTelemetryStore, useTimelineStore } from '../../core/store';
import { TimelineEvent } from '../../core/types';

const valueOf = (metrics: Record<string, number> | undefined, key: string, digits: number) =>
  typeof metrics?.[key] === 'number' ? metrics[key].toFixed(digits) : '—';

export const AquaSenseDashboard: React.FC = () => {
  const latest = useTelemetryStore((state) => state.getLatest());
  const scenario = useScenarioStore((state) => state.scenario);
  const setPhase = useScenarioStore((state) => state.setPhase);
  const advanceElapsed = useScenarioStore((state) => state.advanceElapsed);
  const addEvent = useTimelineStore((state) => state.addEvent);
  const setStatus = useSystemStore((state) => state.setStatus);
  const { send } = useDataBridge(import.meta.env.VITE_WS_URL || 'ws://localhost:8765');

  useEffect(() => {
    if (scenario.status !== 'running') return;
    const interval = setInterval(() => advanceElapsed(0.1 * scenario.speed), 100);
    return () => clearInterval(interval);
  }, [scenario.status, scenario.speed, advanceElapsed]);
  useEffect(() => {
    if (!latest) return;
    setStatus({ online: true, dataStreamActive: true, sensorCount: aquasenseConfig.devices.length });
    setPhase(latest.status === 'critical' ? 'critical' : latest.status === 'warning' ? 'warning' : 'normal');
  }, [latest, setPhase, setStatus]);

  const metrics = latest?.metrics;
  const statusMetrics: StatusMetric[] = [
    { id: 'do', label: 'Dissolved oxygen', value: valueOf(metrics, 'do_mg_l', 2), unit: 'mg/L', tone: metrics?.do_mg_l != null && metrics.do_mg_l < 3.5 ? 'critical' : 'normal' },
    { id: 'temp', label: 'Water temperature', value: valueOf(metrics, 'water_temperature_c', 1), unit: '°C' },
    { id: 'ph', label: 'pH', value: valueOf(metrics, 'ph', 2) },
  ];

  return (
    <Dashboard projectConfig={aquasenseConfig}
      onScenarioStart={(scenarioId, speed) => {
        const selected = aquasenseConfig.scenarios.find((item) => item.id === scenarioId);
        if (!selected) return;
        send({ type: 'start_scenario', project: 'aquasense', scenario: scenarioId, speed });
        setPhase('normal');
        const event: TimelineEvent = { timestamp: new Date().toISOString(), type: 'system_normal', message: `Scenario started: ${selected.name}`, severity: 'info', icon: '▶' };
        addEvent(event);
      }}
      onSpeedChange={(speed) => send({ type: 'set_speed', speed })}
      onScenarioPause={() => send({ type: 'pause' })}
      onScenarioResume={() => send({ type: 'resume' })}
      onScenarioReset={() => send({ type: 'reset' })}
    >
      <FigmaDashboardContent
        metrics={statusMetrics}
        charts={[
          { id:'oxygen', title:'Dissolved oxygen', children:<ThresholdChart metricKey="do_mg_l" title="Biological rhythm · dissolved oxygen" height={220} normalMin={4.5} normalMax={7.5} warningMin={4} warningMax={8} criticalMin={2.5} criticalMax={10} unit="mg/L" /> },
          { id:'temperature', title:'Water temperature', children:<LiveChart metricKeys={['water_temperature_c']} title="Water temperature" height={220} /> },
          { id:'ph', title:'pH', children:<LiveChart metricKeys={['ph']} title="pH" height={220} /> },
        ]}
        insight={<>
          <p><strong>Project:</strong> AquaSense · Pond monitoring</p>
          <p><strong>Scenario:</strong> {scenario.status}</p>
          <p><strong>Device:</strong> {aquasenseConfig.devices[0]?.name ?? 'Not configured'}</p>
          <p>Charts display the existing telemetry stream. Values are shown as unavailable until real or simulated measurements arrive.</p>
        </>}
        logs={<div role="status" aria-live="polite">{latest ? `Telemetry received · Status: ${latest.status ?? 'unknown'}` : 'Waiting for telemetry. Start a scenario using the existing dashboard controls.'}</div>}
      />
    </Dashboard>
  );
};
