# Figma dashboard patch for multifrontend

These are **drop-in source files**, not an independently buildable app. The uploaded source files did not include `core/components`, stores, types, or package.json, so a complete compile cannot be verified here.

## Files to copy

- `frontend/src/core/components/FigmaDashboard/index.tsx` (new)
- `frontend/src/core/components/FigmaDashboard/figma-dashboard.css` (new)
- `frontend/src/projects/aquasense/Dashboard.tsx` (replacement)

Back up the existing AquaSense dashboard or commit it before replacing.

## What it changes

- Reusable light-theme content layout based on the Figma screenshot
- Three status cards and three chart slots, with description and logs sections
- Responsive single-column layout on smaller viewports
- Actual DO / water temperature / pH telemetry via existing stores and chart components
- Preserves existing `<Dashboard>` wrapper and scenario callbacks rather than inventing a second header/footer

## Known integration limits

- Header, settings and scenario footer are still owned by the repo's existing `core/components/Dashboard`, which was not included in uploads. They may differ visually from the screenshot.
- Existing `LiveChart`/`ThresholdChart` may render a dark internal background; style harmonization requires the actual chart component source.
- The chart components' optional/default color props should be checked against the actual repo component typings.
- A local build/test was not possible without the remaining repository and dependencies.
- The logo image is intentionally not included: the uploaded image is a visual reference, and use of the original asset needs a separate asset extraction/placement.

## Suggested workflow

```bash
git switch -c feat/figma-dashboard
# copy the files from this patch into your existing clone
cd frontend
npm install
npm run build
npm run dev
# from repo root, after verifying changes
git add frontend/src/core/components/FigmaDashboard frontend/src/projects/aquasense/Dashboard.tsx
git commit -m "feat: reusable Figma dashboard content layout"
git push -u origin feat/figma-dashboard
```

Inspect `git diff` before committing. Do not overwrite files from any other project.

## Future reuse

Import `FigmaDashboardContent` in another project and provide `metrics`, `charts`, `insight`, and optional `logs` slots. No AquaSense terminology lives in this shared component.
